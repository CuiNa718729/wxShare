/**
 * @author fu
 * @file 我的礼品
 * @CreateTime 08/21/2017
 */

var prizeList = $('.prize-list');
var status = 1; // 领取状态
var nList = 1; // 请求次数
var size = 20;
var orderid = getQueryString('orderid');
var firstLoad = true;
COOKIE = '; ' + document.cookie;
var openId = getCookie('openid') || '';

var index = getQueryString('index') || ''; // 楼卡
// 是否正在加载中
var isLoading = false;
// 是否后台数据已无
var isEnd = false;
// 页数
var page = 1;
// 触发距离
var trigger_distance = 200;
// 无限滚动
var innerHeight = window.innerHeight;
// 未领取页面的提示框
var unclaimed = false;
var flag = false;

wx.ready(function () {
    wx.hideAllNonBaseMenuItem();
});

userInfo();
// 获取用户信息，是否绑定手机
function userInfo() {
    $.ajax({
        url: '/act/rule/' + activityId + '?name=view_user',
        method: 'post',
        success: function (res) {
            var user = res.context.user;
            if (res.code === 1) {
                $('.user').removeClass('invisible');
                $('.user-title').removeClass('invisible');
                var nickname = user.nickname;
                if (user.status === 1) { // 用户未绑定
                    isBind = false;
                    $('.bind-show').addClass('invisible')
                        .siblings('.unbind-show').removeClass('invisible');
                }
                else if (user.status === 2) { // 用户已绑定
                    var mobile = user.mobile;
                    $('#tel_state').text(mobile);
                    isBind = true;
                    mobile = user.mobile;
                    score = user.score;
                    $('.unbind-show').addClass('invisible')
                        .siblings('.bind-show').removeClass('invisible');
                }
                $('.user .name').text(nickname);
                $('.user').find('img').attr('src', user.headImgUrl);
            }
            else {
                if (res.msg.indexOf("SyntaxError") === -1){
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

// 判断是否看楼卡
if (index == 3) { // 楼卡

    lkInterface();
    $('.nav').addClass('invisible');
    $('.footer').addClass('invisible');
    $('#mask').removeClass('invisible');
}
else if (index == 4) {
    $('.l-tips').addClass('invisible');
    prizeList.addClass('m-t3');
    $('.tab-list li').removeClass('active');
    $('.tab-list li:eq(3)').addClass('active');
    coins();
}
else { // 不是楼卡
    // 判断是否有未领取奖品
    $('#mask').removeClass('invisible');
    (function isUnclaimed() {
        $.ajax({
            url: '/award/myorders/'  + activityId + '/' + page + '/' + size + '?status=1',
            method: 'get',
            success: function (res) {

                $('.prize-list').removeClass('invisible').siblings('.floor-card').addClass('invisible');
                $('.tab-list li').removeClass('active');
                if (res.code === 1) {
                    $('.prize-scroll').addClass('nothing');
                    var orders = res.context.orders || [];
                    console.log(orders.length);
                    if (orders.length > 0 ) {
                        unclaimed = false;
                        $('.tab-list li:eq(1)').addClass('active');
                        $('.l-tips').removeClass('invisible');
                        $('.prize-list').removeClass('m-t3');
                        $('.prize-scroll').removeClass('nothing');
                        yetGot(page);
                    }
                    else {
                        alreadyGot(page);
                    }
                }
                else {
                    if (res.msg.indexOf("SyntaxError") === -1){
                        alert(res.msg);
                    }
                    else {
                        alert('服务器繁忙，请稍后重试~');
                    }
                }
            }
        });
    })();
}

// 楼卡接口
function lkInterface() {
    $('.prize-list').addClass('invisible')
        .siblings('.floor-card').removeClass('invisible')
        .siblings('.l-tips').addClass('invisible');
    $('.prize-scroll').removeClass('nothing');
    $('.tab-list li').removeClass('active');
    $('.tab-list li:nth-child(3)').addClass('active');
    $.ajax({
        url: '/act/rule/' + activityId + '?name=card_floor',
        method: 'post',
        data: {
            openid: openId
        },
        success: function (res) {
            if (res.code === 1) {
                var list = JSON.parse(res.context.cardList1);
                // console.log(list);
                var foreHTML = '';
                for (var i = 0; i < list.length; i++) {
                    var num = list[i].cardNum;
                    var type = list[i].cardType;
                    var html = '';
                    var img = list[i].image;
                    // if (num > 1) {
                        html = '<div class="count-style">x' + num + '</div>';
                    // }
                    
                    if (type <= 5) {
                        switch (type) {
                            case 1: // 更
                                // $('.card-item:first-child img').attr('src', img);
                                $('.my-card-list .card-item:first-child').append(html);
                                break;
                            case 2: // 上
                                // $('.card-item:nth-child(2) img').attr('src', img);
                                $('.my-card-list .card-item:nth-child(2)').append(html);
                                break;
                            case 3: // 一
                                // $('.card-item:nth-child(3) img').attr('src', img);
                                $('.my-card-list .card-item:nth-child(3)').append(html);
                                break;
                            case 4: // 层
                                // $('.card-item:nth-child(4) img').attr('src', img);
                                $('.my-card-list .card-item:nth-child(4)').append(html);
                                break;
                            case 5: // 楼
                                // $('.card-item:nth-child(5) img').attr('src', img);
                                $('.my-card-list .card-item:nth-child(5)').append(html);
                                break;
                        }
                    }
                    if (res.context.cy_flag) {
                        $('.cy-list #cy-num').removeClass('gray-color').html(1);
                        
                    }
                    else {
                        foreHTML += '<li class="forecast-item"><img class="card-img" src="' + img + '">' + html + '</li>';
                    }
                }
                $('.forecast-list').html(foreHTML);
                $('#mask').addClass('invisible');
            }
            else {
                if (res.msg.indexOf("SyntaxError") === -1){
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

// 楼卡详情接口
cardDetail();
function cardDetail() {
    $.ajax({
        url:'/act/rule/' + activityId + '?name=card_detail',
        method: 'post',
        success: function (res) {
            if (res.code === 1) {
                var html = '';
                var time = '';
                if (res.context.total) { 
                    var cardList =  JSON.parse(res.context.cardList);

                    for (var i = 0; i < cardList.length; i++) {
                        time = new Date(cardList[i].createTime.split(' ')[0]);
                        html += '<li class="details-item"><span class="red-color">' + time.getFullYear() + '年' + (time.getMonth() + 1) + '月' + time.getDate() + '日' + cardList[i].createTime.split(' ')[1].split('.')[0] + ' </span> 获得一张“<span class="red-color">' +cardList[i].cardName + '</span>”</li>';
                    }

                }
                else { // 没有楼卡
                    html = '<li><img class="details-empty" src="https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/img/my_prize/details_empty.png"></li><li class="empty-text">你还没有楼卡，<br>赶快去扫码集卡吧！</li>';
                    $('.details-list').css('overflow-y', 'hidden');
                }
                $('.details-list').html(html);
            }
            else {
                if (res.msg.indexOf("SyntaxError") === -1){
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

// 待领取
function yetGot(page) {
    $('.tab-list li').eq(1).addClass('active');
    $('#mask').removeClass('invisible');
    $.ajax({
        url: '/award/myorders/'  + activityId + '/' + page + '/' + size + '?status=1',
        method: 'get',
        success: function (res) {
            var code = res.code;
            // if (code == 403) {
            //     beforegotologin();
            //     window.location.replace('redirect.html');
            // }
            if (code === 1) {
                $('.prize-list .more').remove();
                $('.prize-list').removeClass('invisible').siblings('.floor-card').addClass('invisible');
                var orders = res.context.orders;
                // console.log(orders.length);
                if (page < 2) {
                    if (orders.length > 0) {
                        unclaimed = false;
                        $('.prize-scroll').removeClass('nothing');
                        $('.l-tips').removeClass('invisible');
                        $('.prize-list').removeClass('m-t3');
                        isLoading = false;
                        showYetGotPrizes(orders);
                    }
                    else {
                        $('.prize-scroll').addClass('nothing');
                        $('#mask').addClass('invisible');
                        unclaimed = true;
                        isLoading = true;
                        $('.l-tips').addClass('invisible');
                    }
                }
                else {
                    if (orders.length == 0) {
                        isEnd = true;
                        // $('.prize-list').append('<p class="nomore" style="margin-top: 0.4rem; color: #ffa544; text-align: center; font-size: 0.3rem;">没有更多了~</p>');
                    }
                    else {
                        isLoading = false;
                        showYetGotPrizes(orders);
                    }
                }
                if (orders.length < 20 && orders.length > 0) {
                    $('.prize-list').append('<p class="nomore" style="margin-top: 0.4rem; color: #ffa544; text-align: center; font-size: 0.3rem;">没有更多了~</p>');
                    return;
                }
                // console.log(orders.length);
                $(window).off().on('scroll', function () {
                    if ($('.main .tab-list li.active').index() === 1) {
                        fetchData(yetGot);
                    }
                });
            }
            else {
                if (res.msg.indexOf('SyntaxError') === -1) {
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

function showYetGotPrizes(orders) {
    var _html = '';
    orders.forEach(function (n, index) {
        var type = n.complexOrder.order.orderType;
        var award = n.complexOrder.details[0] || {};

        if (award != {}) {
            // console.log(n.is_get);
            var isGet = n.is_get === 1 ? '' : 'failure-mask'; // 1 可领取 0 不可领取
            // console.log(isGet);
            var assisting = n.is_zhuli === 1 ? 'assisting-bg' : ''; // 1 需要助力 0 不需要助力
            var status = n.complexOrder.order.status;
            var btn_text = '详情';
            var assistingPrice = award.price;
            if (n.is_zhuli === 1) {
                if (n.is_finish === 1) { // 已助力成功
                    btn_text = '成功';
                }
                else if (n.is_get === 0) { // 已过期
                    btn_text = '失效';
                }
                var btn_html = '<div class="detail model1" data-status="0" data-click="assisting-btn" data-source="' + n.complexOrder.order.source + '"  data-orderid="' + award.orderid + '" data-type="' + type + '" data-img="' + award.productImage + '" data-price="' + award.price + '">' + btn_text + '</div>';
                _html += '<li class="each assisting-bg" data-status="' + n.complexOrder.order.status + '" class="prize-list"><img class="img" src="' + award.productImage + '" alt=""><p class="prz-h">' + award.productName + '</p><p class="date create">获得时间:' + n.complexOrder.order.createTime.replace(/-/g, '/')  + '</p><p class="orderNo">订单号:'+ n.complexOrder.order.orderid + '</p>' + btn_html + '<div class="' + isGet + '"></div></li>';
            }
            else {
                if (n.is_get === 0) { // 已失效
                    var btn_html = '<div class="detail model1 gray-color_c" data-status="0" data-click="btn" data-source="' + n.complexOrder.order.source + '"  data-orderid="' + award.orderid + '" data-type="' + type + '">失效</div>';
                }
                else {
                    var btn_html = '<div class="detail model1" data-status="0" data-click="btn" data-source="' + n.complexOrder.order.source + '"  data-orderid="' + award.orderid + '" data-type="' + type + '">领取</div>';
                }
                // var btn_html = '<div class="detail model1" data-status="0" data-click="btn" data-source="' + n.complexOrder.order.source + '"  data-orderid="' + award.orderid + '" data-type="' + type + '">领取</div>';
                _html += '<li class="each '+ assisting + '" data-status="' + n.complexOrder.order.status + '" class="prize-list"><img class="img" src="' + award.productImage + '" alt=""><p class="prz-h">' + award.productName + '</p><p class="date create">获得时间:' + n.complexOrder.order.createTime.replace(/-/g, '/')  + '</p><p class="orderNo">订单号:'+ n.complexOrder.order.orderid + '</p>' + btn_html + '<div class="' + isGet + '"></div></li>';
            }
        }
    });

    prizeList.append(_html);
    $('#mask').addClass('invisible');
    $('[data-click="btn"]').on('click', function (e) {
        var order_id = $(this).data('orderid');
        var type = $(this).data('type');
        if ($(this).hasClass('gray-btn')) { // 已超过领取有效期
            return;
        }
        if (isBind == false) {
            $('.phone-line').text('首次领奖，请激活手机号');
            $('.pop').removeClass('invisible')
                .children('.phone').removeClass('invisible')
                .siblings('.bind').addClass('invisible');
        }
        else {
            if (parseInt($(this).data('source'))) {
                window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?orderid=' + order_id + '&isZhuli=0';
            }
            else {
                window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?testing=0&orderid=' + order_id + '&isZhuli=0';
            }
        }
    });

    // 助力按钮
    $('[data-click="assisting-btn"]').on('click', function () {
        var order_id = $(this).data('orderid');
        var assisitingImg = $(this).data('img');
        var assistingPrice = $(this).data('price');
        console.log(assistingPrice);
        window.location.href = '/a/p/guangxi-jins-cons-assisting-activity.html?user_openid=' + openId + '&orderid=' + order_id + '&img=' + assisitingImg + '&price=' + assistingPrice;
    });
}

// 已领取
function alreadyGot(page) {
    $('.l-tips').addClass('invisible');
    $('.prize-list').addClass('m-t3');
    $('.tab-list li:eq(0)').addClass('active');
    $('#mask').removeClass('invisible');
    $.ajax({
        url: '/award/myorders/'  + activityId + '/' + page + '/' + size + '?status=2',
        method: 'get',
        success: function (res) {
            var code = res.code;
            // if (code == 403) {
            //     beforegotologin();
            //     window.location.replace('redirect.html')
            // }
            if (code === 1) {
                $('.prize-list .more').remove();
                $('.prize-list').removeClass('invisible').siblings('.floor-card').addClass('invisible');
                var orders = res.context.orders;
                if (page < 2) {
                    if (orders.length == 0) {
                        isLoading = true;
                        $('.prize-scroll').addClass('nothing');
                    }
                    else {
                        $('.prize-scroll').removeClass('nothing');
                        isLoading = false;
                        showAlreadyGotPrizes(orders);
                    }
                }
                else {
                    if (orders.length == 0) {
                        isEnd = true;
                        // $('#prizeList').append('<p class="nomore" style="margin-top: 0.4rem; text-align: center; color: #ffa544; font-size: 0.3rem; ">没有更多了~</p>');
                    }
                    else {
                        isLoading = false;
                        showAlreadyGotPrizes(orders);
                    }
                }
                if (orders.length < 20 && orders.length > 0) {
                    $('.prize-list').append('<p class="nomore" style="margin-top: 0.4rem; color: #ffa544; text-align: center; font-size: 0.3rem;">没有更多了~</p>');
                    return;
                }
                else {
                    $(window).off().on('scroll', function () {
                        // console.log('b');
                        // console.log($('.main .tab-list li.active').index());
                        if ($('.main .tab-list li.active').index() === 0) {
                            fetchData(alreadyGot);
                        }
                    });
                }
                $('#mask').addClass('invisible');
            }
            else {
                if (res.msg.indexOf("SyntaxError") === -1){
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

function showAlreadyGotPrizes(orders) {
    var _html = '';
    orders.forEach(function (n, index) {
        var type = n.complexOrder.order.orderType;
        var award = n.complexOrder.details[0] || {};
        if (award != {}) {
            // var assisting = n.is_zhuli === 1 ? 'assisting-bg' : ''; // 1 
            var status = n.complexOrder.order.status;
            var btn_html = '<div data-status="1" class="detail model1" data-click="btn" data-source="' + n.complexOrder.order.source + '" data-orderid="' + award.orderid + '" data-type="' + type + '">详情</div>';
            if (n.is_zhuli === 1) {
                _html += '<li class="each assisting-bg" data-status="' + n.complexOrder.order.status + '" class="prize-list"><img class="img" src="' + award.productImage + '" alt=""><p class="prz-h">' + award.productName + '</p><p class="date create">获得时间:' + n.complexOrder.order.createTime.replace(/-/g, '/')  + '</p><p class="orderNo">订单号:'+ n.complexOrder.order.orderid + '</p>' + btn_html + '</li>';
            }
            else {
                _html += '<li class="each" data-status="' + n.complexOrder.order.status + '" class="prize-list"><img class="img" src="' + award.productImage + '" alt=""><p class="prz-h">' + award.productName + '</p><p class="date create">获得时间:' + n.complexOrder.order.createTime.replace(/-/g, '/')  + '</p><p class="orderNo">订单号:' + n.complexOrder.order.orderid + '</p>' + btn_html + '</li>';
            }
        }
    });

    prizeList.append(_html);
    $('#mask').addClass('invisible');
    $('[data-click="btn"]').on('click', function (e) {
        var order_id = $(this).data('orderid');
        var type = $(this).data('type');
        console.log($(this).data('source'));
        if (parseInt($(this).data('source'))) {
            window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?orderid=' + order_id + '&iphone=no&cache=false&isZhuli=0';
        }
        else {
            window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?testing=0&orderid=' + order_id + '&iphone=no&cache=false&isZhuli=0';
        }
    });

}

// 展示金币
function showPoints(orders) {
    var _html = '';
    if (orders.length === 0) {
        $('.prize-scroll').addClass('nothing');
        $('#mask').addClass('invisible');
    }
    else {
        orders.forEach(function (n, index) {
            var img = (n.memo == null) ? '' : n.memo;
            var btn_html = '<div data-img="https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/img/egg_frenzy/integral_' + n.score + '.png" data-score="' + n.score + '" data-time="' + n.createTime + '" class="detail model1" data-click="points" data-type="0">详情</div>';
            _html += '<li class="each" data-status="" class="prize-list"><img class="img" src="https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/img/egg_frenzy/integral_' + n.score + '.png" alt=""><p class="coin-h">积分' + n.score + '个</p><p class="date create">获得时间: ' + n.createTime + '</p>' + btn_html + '</li>';
        });

        prizeList.append(_html).removeClass('invisible');
        $('#mask').addClass('invisible');
        $('[data-click="points"]').on('click', function (e) {
            var img = $(this).data('img');
            var score = $(this).data('score');
            var createTime = $(this).data('time');
            var lkImg = 'https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/img/egg_frenzy/integral_' +  score + '.png';
            window.sessionStorage.setItem('lkImg', img)
            window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?lkImg=' + lkImg + '&score=' + score + '&createTime=' + createTime + '&iphone=no&cache=false&isZhuli=0';
        });
    }
}

// 积分展示
function coins() {
    $('.floor-card').addClass('invisible');
    $('#mask').removeClass('invisible');
    $.ajax({
        url: '/act/rule/' + activityId + '?name=points_page',
        method: 'post',
        data: {
            size: 20,
            page: page
        },
        success: function (res) {
            var code = res.code;
            if (code === 1) {
                var points = JSON.parse(res.context.points);
                showPoints(points);
            }
            else {
                if (res.msg.indexOf('SyntaxError') === -1) {
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

// 导航栏切换
$('.main .tab-list li').off().on('click', function () {
    if ($(this).hasClass('active')) {
        return;
    }
    prizeList.html('');
    prizeList.children().empty();
    page = 1;
    isLoading = false;
    isEnd = false;
    // console.log($(this).index());
    $('.prize-scroll').removeClass('nothing');
    $('.nav').removeClass('invisible');
    $('.footer').removeClass('invisible');
    $('.tab-list li').removeClass('active');
    if ($(this).index() === 1) { // 未领取
        if (unclaimed === true) {
            $('.unclaimed').removeClass('invisible');
        }
        yetGot(page);
    }
    else if ($(this).index() === 0) { // 已领取
        $('.unclaimed').addClass('invisible');
        alreadyGot(page);
    }
    else if ($(this).index() === 2) { // 楼卡
        lkInterface();
        $('.nav').addClass('invisible');
        $('.footer').addClass('invisible');
    }
    else if ($(this).index() === 3) { // 积分
        $('.l-tips').addClass('invisible');
        prizeList.addClass('m-t3');
        $(this).addClass('active').siblings().removeClass('active');
        coins();
    }
});

// 下拉刷新
function fetchData(fn) {
    var scrollTop = $(window).scrollTop();
    var scrollHeight = $(document).height();
    var windowHeight = $(window).height();
    var distance = $(prizeList).offset().top - $(window).scrollTop();
    if (!isLoading && !isEnd && (scrollTop + windowHeight == scrollHeight)) {
        console.log('a');
        console.log($('.main .tab-list li.active').index());
        isLoading = true;
        page++;
        $('.prize-list').append('<p class="more" style="margin-top: 0.4rem; color: #ffa544; text-align: center; font-size: 0.3rem;">加载中！~</p>');
        fn.call(window, page);
    }
}

// 解绑按钮
$('[data-click="jiebang"]').click(function () {
    var mobile = $('#tel_state').text();
    opType = $(this).data('optype');
    // console.log(opType);
    $('.phone-line').text('解绑当前手机号');
    $('#p_phone').val(mobile);
    $('#p_phone').attr('readonly', true);
    $('.pop').removeClass('invisible')
        .children('.phone').removeClass('invisible')
        .siblings('.bind').addClass('invisible');
});

// 绑定按钮
$('[data-click="bangding"]').click(function () {
    opType = $(this).data('optype');
    console.log(opType);
    $('.phone-line').text('首次领奖，请激活手机号');
    $('.pop').removeClass('invisible')
        .children('.phone').removeClass('invisible')
        .siblings('.bind').addClass('invisible');

});

// cookie中取值 cookie中有barcode和scan_count
function getCookie(name) {
    var parts = COOKIE.split('; ' + name + '=');
    if (parts && parts.length === 2) {
        return parts[1].slice(0, parts[1].indexOf(';'));
    }
}

// 我发起的交换

// $('[data-click="my-change"]').click(function () {
//     window.location.href = window.location.origin + '/a/p/guangxi-jins-card-list.html';
// });

// // 我要换卡
// $('.floor-card').on('click', '[data-click="want-change"]', function () {
//     window.location.href = window.location.origin + '/a/p/guangxi-jins-card-exchange.html';
// });

// 楼卡详情展示按钮
$('#details-btn').click(function () {
    $('.details-pop').removeClass('invisible');
});

// 楼卡详情弹窗关闭按钮

$('#details-close').click(function () {
    $('.details-pop').addClass('invisible');
});

// // 判断是否是安卓手机
// if (!isAndroid()) {
//     $('.prize-list').removeClass('margin-b1');
//     $('.floor-card').removeClass('margin-b1');
// }

// function isAndroid() {
//     var ua = navigator.userAgent.toLowerCase();
//     if (ua.match(/Android/i) == "android") {
//         alert('true');
//         return true;
//     }
//     else {
//         alert('false');
//         return false;
//     }
// }




