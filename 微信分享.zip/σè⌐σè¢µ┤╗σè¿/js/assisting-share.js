/**
 * @author fu
 * @file 助力分享
 * @CreateTime 05/04/2018
**/

wx.config({
    debug: false,
    appId: weixin_token.appId,
    timestamp: weixin_token.timestamp,
    nonceStr: weixin_token.nonceStr,
    signature: weixin_token.signature,
    jsApiList: [
        'checkJsApi',
        'onMenuShareTimeline', // 分享到朋友圈
        'onMenuShareAppMessage', // 分享给朋友
        'onMenuShareQQ', // 分享到QQ
        'onMenuShareWeibo', // 分享到微博
        'onMenuShareQZone', // 分享到QZone
        // 'hideMenuItems',
        'showMenuItems',
        // 'hideAllNonBaseMenuItem',
        'showAllNonBaseMenuItem',
        // 'hideOptionMenu',
        'showOptionMenu'
    ]
});
// 分享对象
var actObj = {
    shareImg: getQueryString('img') || img,
    price: getQueryString('price') || price, // 获得金额
    userOpenid: getQueryString('user_openid') || userOpenid, // 发起人openid
    orderid: getQueryString('orderid') || orderid // 订单id
};

wx.ready(function () {
    wx.showAllNonBaseMenuItem();
    var pre_fix = location.origin;
    // var pathname = location.pathname;
    var shareLink = pre_fix + '/a/p/guangxi-jins-cons-assisting-activity.html?cache=false&user_openid=' + actObj.userOpenid + '&orderid=' + actObj.orderid + '&img=' + actObj.shareImg + '&price=' + actObj.price;

    // shareLink = _joyAnalytics.countLevel(shareLink);
    var shareTitle = '我中了' + actObj.price + '元奖励金，帮我拆一下吧！';
    var shareDesc = '就差你了，朋友！';
    var shareImg = actObj.shareImg;
    wx.onMenuShareTimeline({
        title: shareTitle, // 分享标题
        link: shareLink, // 分享链接
        imgUrl: shareImg, // 分享图标
        success: function () {
            // 用户确认分享后执行的回调函数
            // _joyAnalytics.send("share", {
            //     aid: 'S000004'
            // });
            $('.pop-assisting').addClass('invisible');
            window.sessionStorage.setItem('need_zhuli', false);
            $('.tip-content p').addClass('invisible');
            $('.assisting-tip').removeClass('invisible');
            $('.assisting-share_btn').removeClass('invisible');
            $('.tip-content').removeClass('invisible');

        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
        }
    });
    wx.onMenuShareAppMessage({
        title: shareTitle,
        desc: shareDesc,
        link: shareLink,
        imgUrl: shareImg,
        type: 'link', // 分享类型,music、video或link，不填默认为link
        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
        success: function () {
            // 用户确认分享后执行的回调函数
            // _joyAnalytics.send("share", {
            //     aid: 'S000003'
            // });
            $('.pop-assisting').addClass('invisible');
            window.sessionStorage.setItem('need_zhuli', false);
            $('.tip-content p').addClass('invisible');
            $('.assisting-tip').removeClass('invisible');
            $('.assisting-share_btn').removeClass('invisible');
            $('.tip-content').removeClass('invisible');
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
        }
    });
    wx.onMenuShareQQ({
        title: shareTitle,
        desc: shareDesc,
        link: shareLink,
        imgUrl: shareImg,
        type: 'link', // 分享类型,music、video或link，不填默认为link
        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
        success: function () {
            // 用户确认分享后执行的回调函数
            // _joyAnalytics.send("share", {
            //     aid: 'S000002'
            // });
            $('.pop-assisting').addClass('invisible');
            window.sessionStorage.setItem('need_zhuli', false);
            $('.tip-content p').addClass('invisible');
            $('.assisting-tip').removeClass('invisible');
            $('.assisting-share_btn').removeClass('invisible');
            $('.tip-content').removeClass('invisible');
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
        }
    });
    wx.onMenuShareQZone({
        title: shareTitle,
        desc: shareDesc,
        link: shareLink,
        imgUrl: shareImg,
        type: 'link', // 分享类型,music、video或link，不填默认为link
        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
        success: function () {
            // 用户确认分享后执行的回调函数
            // _joyAnalytics.send("share", {
            //     aid: 'S000005'
            // });
            $('.pop-assisting').addClass('invisible');
            window.sessionStorage.setItem('need_zhuli', false);
            $('.tip-content p').addClass('invisible');
            $('.assisting-tip').removeClass('invisible');
            $('.assisting-share_btn').removeClass('invisible');
            $('.tip-content').removeClass('invisible');
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
        }
    });
    wx.onMenuShareWeibo({
        title: shareTitle,
        desc: shareDesc,
        link: shareLink,
        imgUrl: shareImg,
        type: 'link', // 分享类型,music、video或link，不填默认为link
        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
        success: function () {
            // 用户确认分享后执行的回调函数
            // _joyAnalytics.send("share", {
            //     aid: 'S000006'
            // });
            $('.pop-assisting').addClass('invisible');
            window.sessionStorage.setItem('need_zhuli', false);
            $('.tip-content p').addClass('invisible');
            $('.assisting-tip').removeClass('invisible');
            $('.assisting-share_btn').removeClass('invisible');
            $('.tip-content').removeClass('invisible');
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
        }
    });
});
