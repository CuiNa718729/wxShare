/**
 * @author fu
 * @file 订单详情  三选一
 * @CreateTime 08/21/2017
**/
var orderid = getQueryString('orderid') || window.sessionStorage.getItem('orderid') || ''; // 订单ID
var isSuccess = getQueryString('isSuccess'); // 集齐全套楼卡
var isVip = getQueryString('isVip'); // 成为vip
var pid = getQueryString('pid');
var cardType = window.sessionStorage.getItem('cardType'); // 得到的楼卡type  三选一
var isNeedChoose = window.sessionStorage.getItem('isNeedChoose') || 'false';   // 是否需要交换
var code = getQueryString('code');
var alreadyChange = window.sessionStorage.getItem('alreadyChange') || '';  // 是否已经交换过
var price = window.sessionStorage.getItem('price') || ''; // 红包金额 用于判断交换之后是否是红包
COOKIE = '; ' + document.cookie;
var user_openid = window.sessionStorage.getItem('user_openid') || getCookie('user_openid');

var iphone = getQueryString('iphone') || '';  // 是否可以参加苹果抽奖

var lkImg = window.sessionStorage.getItem('lkImg') || getQueryString('lkImg') || '';  // 奖品图片
var score = getQueryString('score') || window.sessionStorage.getItem('score') || '';  // 获得积分
var createTime = getQueryString('CreateTime') || window.sessionStorage.getItem('createTime') || '';

var barcode = window.sessionStorage.getItem('barcode') || '';  // 跳转到积分商城的参数
var authstr = window.sessionStorage.getItem('authstr') || '';  // 跳转到积分商城的参数
var timeStamp = window.sessionStorage.getItem('timeStamp') || '';  // 跳转到积分商城的参数

// 助力字段
var img = '';
var isZhuli = '';
console.log(getQueryString('isZhuli'));
// if (getQueryString('isZhuli') !== null || getQueryString('isZhuli') !== undefined) {
    isZhuli = parseInt(getQueryString('isZhuli')) || ''; // 从我的礼品页面进入需要判断
// }

var userOpenid = window.sessionStorage.getItem('user_openid') || ''; // 发起人的openid
var need_zhuli = window.sessionStorage.getItem('need_zhuli') || 'false'; // 是否需要助力
var alreadyShare = window.sessionStorage.getItem('alreadyShare') || ''; //助力活动当前页面刷新之后判断不调红包接口
if (need_zhuli === 'false' || isZhuli === 0) {
    wx.ready(function () {
        wx.hideAllNonBaseMenuItem();
    });
}
else if (need_zhuli === 'true') { // 需要助力
    $('.pop-assisting').removeClass('invisible');
    $('.assisting-step1').removeClass('invisible');
    window.sessionStorage.setItem('alreadyShare', true);
}
// else {
//     wx.ready(function () {
//         wx.hideAllNonBaseMenuItem();
//     });
// }

var title = '登顶大赛';
var canIphone = false;

// if (barcode != '' && authstr != '' && timeStamp != '') {  // 楼卡
//     href();
// }

// else if (iphone == 'no' && score !== '') {
//     $('.banner-2').attr('href', 'javascript:;');
//     $('.banner-2').click(function () {
//         alert('抱歉，您没获得抽奖机会，感谢您的参与!');
//         return;
//     });
// }

var testing = getQueryString('testing') || 1; // 判断是否从砸金蛋页面跳转
// 查看订单详情
var telReg = /^1[3|4|5|6|7|8][0-9]\d{8}$/;

if (!parseInt(testing)) {
    $('.testing').addClass('invisible');
    $('.sw_txt').addClass('margin-top116');
    $('.success').addClass('margin-top116');
    $('.failure').addClass('margin-top116');
}

function integral() {
    // 助力展示关闭
    $('.pop-assisting').addClass('invisible');
    $('.tip-content').addClass('invisible');

    $('.hb_prize').removeClass('invisible');
    $('.success').removeClass('invisible');
    $('#award .padding-top2').html('恭喜您获得' + score + '积分<br/><div id="creat-time">获得时间' + decodeURI(createTime) + '</div>').addClass('padding-top5');
    $('.hb_prize .prizeImg').attr('src', lkImg);
    // $('#creat-time').html('获得时间：' + decodeURI(createTime)).addClass('margin-top5');
    $('.lk-tip p').html('1、积分已放入您在积分商城的账户，注册后即可领取；</br>2、必须使用砸金蛋绑定的手机号进行注册。</br>3、积分用于在积分商城兑换超值商品；</br>4、还可通过完善个人资料、完成推荐任务等获得更多积分。');
    $('.lk-tip').removeClass('invisible').addClass('padding-top0');
    $('.points-enter').removeClass('invisible');
}
// 判断是不是楼卡，楼卡没有orderid
if (score !== '') { // 积分
    integral();
}
else if (orderid === '') { // 楼卡
    $('.hb_prize').removeClass('invisible');
    $('#award .padding-top2').html('恭喜您获得楼卡1张');
    $('.success').removeClass('invisible');
    $('.hb_prize .prizeImg').attr('src', lkImg);
    $('.lk-tip').removeClass('invisible');
    // if (pid === 'jxjinsxrp-card-cy') { // 重阳卡
    //     setTimeout(function () {
    //         $('.pop-cy').slideDown("slow");
    //     }, 100);
    // }
    if (isNeedChoose != 'false') {
        // 三选一
        console.log(isNeedChoose);
        switch (parseInt(cardType)) {
            case 1:
                $('#card-name').html('更');
                break;
            case 2:
                $('#card-name').html('上');
                break;
            case 3:
                $('#card-name').html('一');
                break;
            case 4:
                $('#card-name').html('层');
                break;
            case 5:
                $('#card-name').html('楼');
                break;
        }
        $('.change-pop').removeClass('invisible');
    }
    else {
        isTrue();
    }
}
else {
    if (alreadyChange !== 1) {
        awardOrder();
    }
    else if (price !== '') { // 红包
        $('.win-text span').text(price + '元');
        $('.fail-text span').text(price + '元');
        $('.hb_prize').removeClass('invisible');
        $('.lk-tip').addClass('padding-top3');
        if (window.sessionStorage.getItem('isFailure') == 1) {  // 红包领取失败
            $('.failure').removeClass('invisible')
                .siblings('.success').addClass('invisible');
            $('.failure-info').removeClass('invisible')
                .siblings('.tip-content').addClass('invisible');
        }
        else { // 红包领取成功
            $('.prizeImg').attr('src', lkImg);
        }
    }
}

// 判断是否是会员或者是否集齐楼卡
function isTrue() {
    $('.pop-transparent').addClass('invisible');
    if (eval(isVip)) {
        setTimeout(function () {
            $('.pop-detail').removeClass('invisible')
                .children('.vip').removeClass('invisible');
            $('.collect').addClass('invisible');
        }, 1000);
    }
    else if (eval(isSuccess)) {
        setTimeout(function () {
            $('.pop-detail').removeClass('invisible')
                .children('.collect').removeClass('invisible');
            $('.vip').addClass('invisible');
        }, 1000);
    }
}

// 获得奖品
function awardOrder() {
    $.get('/award/order', {
        orderid: orderid,
        activityId: activityId
    }, function (res) {
        if (res.code === 1) {
            var order = res.context.order;
            var details = res.context.details[0];
            var price = details.price;
            if (price !== 8.8 && price !== 18 && price !== 28 && price !== 88) {
                isZhuli = 0;
            }
            img = details.productImage;
            var prizeName = details.productName;
            var productId = details.productId;
            if (new Date(res.context.order.createTime.replace(/-/g, '/')).getTime() >= 1515978000000) {
                canIphone = true;
            }

            barcode = res.context.order.memo;
            authstr = res.context.authStr;
            timeStamp = res.systemTime;
            // href();
            $('.prizeImg').attr('src', img);

            if (res.context.delivery) { // 用户已填写地址
                $('#get-prize').html('查看订单地址');
            }

            if (order.status === 0) { // 未领取
                if (order.orderType === 2 ) { // 红包
                    $('.win-text span').text(price + '元');
                    $('.fail-text span').text(price + '元');
                    $('.hb_prize').removeClass('invisible');
                    $('.lk-tip').addClass('padding-top3');

                    var pre_fix = location.origin;
                    if (need_zhuli == 'true' && isZhuli !== 0 && score === '') {
                        console.log(isZhuli);
                        $('body').append('<script src="https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/js/assisting-share.js"></script>');
                        $('.pop-assisting').removeClass('invisible');
                        $('.assisting-step1').removeClass('invisible');
                        $('.assisting-join').removeClass('invisible');
                    }
                    else if (alreadyShare == 'true' && isZhuli === '') { // 获得助力红包，刷新页面展示
                        $('.assisting-join').removeClass('invisible');
                        $('.tip-content p').addClass('invisible');
                        $('.assisting-tip').removeClass('invisible');
                        $('.assisting-share_btn').removeClass('invisible');
                        $('.tip-content').removeClass('invisible');
                    }
                    else {
                        console.log('alreadyShare:' + alreadyShare);
                        console.log('isZhuli: ' + isZhuli);
                        $('.pop-assisting').addClass('invisible');
                        $('.tip-content').addClass('invisible');
                        orderList();
                        $('.tip-content').removeClass('invisible')
                        .siblings('.failure-info').addClass('invisible');
                    }

                    $('.success').removeClass('invisible')
                        .siblings('.failure').addClass('invisible');
                    // $('.tip-content').removeClass('invisible')
                    //     .siblings('.failure-info').addClass('invisible');
                }

                if (order.orderType === 3 ) { // 实物奖品
                    $('.sw_txt').removeClass('invisible');
                    $('.sw_txt .win-prize').addClass('padding-top3');
                    $('.sw_txt .win-text').html('恭喜您获得' + prizeName);

                    $.ajax({
                        url: '/sku/item/' + productId,
                        data: {
                            activityId: activityId
                        },
                        method: 'get',
                        success: function (res) {
                            if (res.code === 1) {
                                $('.sw_txt .txt').html(res.context.sku.description);
                            }
                            else {
                                if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                                    alert(res.msg);
                                }
                                else {
                                    alert('服务器繁忙，请稍后重试~');
                                }
                            }
                        }
                    });
                    $('.sw_prize').removeClass('invisible');
                    $('#get-prize').on('click', function () {
                        window.location.href = window.location.origin + '/a/p/common-order-delivery-v1.html?activityId=' + activityId + '&orderid=' + orderid;
                    });
                }
            }
            else if (order.status === 2 || order.status === 1) { // 已领取
                if (order.orderType === 2 ) {  // 红包
                    $('.win-text span').text(price + '元');
                    $('.hb_prize').removeClass('invisible');
                    $('.success').removeClass('invisible')
                        .siblings('.failure').addClass('invisible');
                    $('.tip-content').removeClass('invisible')
                        .siblings('.failure-info').addClass('invisible');
                }

                if (order.orderType === 3 ) { // 实物奖品
                    $('.sw_txt').removeClass('invisible');
                    $('.sw_txt .win-prize').addClass('padding-top3');
                    $('.sw_txt .win-text').html('恭喜您获得' + prizeName);

                    $.ajax({
                        url: '/sku/item/' + productId,
                        data: {
                            activityId: activityId
                        },
                        method: 'get',
                        success: function (res) {
                            if (res.code === 1) {
                                $('.sw_txt .txt').html(res.context.sku.description);
                            }
                            else {
                                if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                                    alert(res.msg);
                                }
                                else {
                                    alert('服务器繁忙，请稍后重试~');
                                }
                            }
                        }
                    });
                    $('.sw_prize').removeClass('invisible');
                    $('#get-prize').on('click', function () {
                        window.location.href = window.location.origin + '/a/p/common-order-delivery-v1.html?activityId=' + activityId + '&orderid=' + orderid;
                    });
                }
            }

            // 助力展示
            $('.assisting-img').attr('src', details.productImage);
            $('.assisting-price').html(price + '元');
            switch(price) {
                case 8.8:
                    $('.assisting-people').html('2');
                    $('.assisting-score').html('20积分');
                    break;
                case 18:
                    $('.assisting-people').html('3');
                    $('.assisting-score').html('50积分');
                    break;
                case 28:
                    $('.assisting-people').html('5');
                    $('.assisting-score').html('100积分');
                    break;
                case 88:
                    $('.assisting-people').html('10');
                    $('.assisting-score').html('200积分');
                    break;
            }
            isTrue();
        }
        else {
            if (res.msg.indexOf('SyntaxError') === -1) {
                alert(res.msg);
            }
            else {
                alert('服务器繁忙，请稍后重试~');
            }
        }
    });
}

// 领取红包
function orderList() {
    $.post('/award/accept2', {
        orderid: orderid,
        activityId: activityId
    }, function (res) {
        if (res.code === 1) {
            var img = res.context.details[0].productImage;
            window.sessionStorage.setItem('lkImg', img);
            $('.prizeImg').attr('src', img);
        }
        else {
            window.sessionStorage.setItem('isFailure', 1);
            $('.failure').removeClass('invisible')
                .siblings('.success').addClass('invisible');
            $('.failure-info').removeClass('invisible')
                .siblings('.tip-content').addClass('invisible');
        }
    });
}

$('.a-close').click(function () {
    $('.pop-adress').addClass('invisible');
});

$('[data-click="jump-myprize-lk"]').click(function () {
    window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-my-prize.html?index=' + 3; // 跳转到我的礼品-> 楼卡
});

$('.pop-cy .close').click(function () {
    $('.pop-cy').slideUp('slow');
});

// 弹窗关闭按钮
$('.detail-close').click(function () {
    $('.pop-transparent').addClass('invisible');
    $(this).parent().addClass('invisible')
        .parent('.pop-detail').addClass('invisible');
});

// 交换红包
var changeType = ''; // 1是领取楼卡 2 红包 4 积分
$('.change-btns li').click(function () {
    console.log($(this).index());
    var index = $(this).index();
    if (index === 1) { // 换诚信奖励
        changeType = 2;
    }
    else if (index === 2) { // 换30积分
        changeType = 4;
    }
    else { // 不换
        changeType = 1;
    }
    changeRedPack();
});

// 三选一接口
function changeRedPack() {
    var cardFriendId = window.sessionStorage.getItem('cardFriendId');
    var userId = window.sessionStorage.getItem('userId');
    $.ajax({ // /act/rule/JS0001DS001?name=card_choose_three
        url: '/act/rule/' + activityId + '?name=card_choose_three',
        data: {
            code: code,
            cardType: cardType,
            changeType:  changeType,
            cardFriendId: cardFriendId,
            userId: userId
        },
        method: 'post',
        success: function (res) {
            if (res.code === 1) {
                window.sessionStorage.setItem('alreadyChange', 1);
                window.sessionStorage.setItem('isNeedChoose', false);
                if (res.context.cardType != undefined) {
                    location.reload();
                }
                else {
                    // alert('不是楼卡');
                    if (res.context.pointImage != undefined) { // 中积分
                        score = res.context.points;
                        createTime = res.context.date;
                        lkImg = res.context.pointImage;
                        window.sessionStorage.setItem('lkImg', lkImg);
                        window.sessionStorage.setItem('score', score);
                        window,sessionStorage.setItem('createTime', createTime);
                        integral();
                        $('.change-pop').addClass('invisible');
                    }
                    else { // 红包
                        orderid = res.context.details[0].orderid;
                        window.sessionStorage.setItem('orderid', orderid);
                        window.sessionStorage.setItem('price', res.context.details[0].price);
                        $('.fail-text span').text('1元');
                        orderList();
                        $('.change-pop').addClass('invisible');
                        $('.lk-tip').addClass('invisible');
                        $('.tip-content').removeClass('invisible');
                        $('.padding-top2').html('<p class="text">产品信息：金圣(滕王阁·更上一层楼)</p><p>感谢支持正品，送您诚信奖励！</p>');
                    }
                }
            }
            else {
                if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

function href() {
    if (barcode == '' || barcode == null || barcode == undefined || authstr == '' || timeStamp == '' || (iphone == 'no' && !canIphone)) {  
        $('.banner-2').attr('href', 'javascript:;');
        $('.banner-2').click(function () {
            alert('抱歉，您没获得抽奖机会，感谢您的参与!');
        });
        return;
    }
    $.post(
        '/act/feedback/add',
        {
            activityId: activityId,
            title: title,
            content: 'http://ewm.jinsheng.com/act/summit/red.html?barcode=' + barcode + '&timeStamp=' + timeStamp + '&authStr=' + authstr
        },
        function (res) {
            console.log('请求成功！');
        }
    );
    $('.banner-2').off('click');
    // 登顶大会 链接地址 小包地址 
    $('.banner-2').attr('href', 'http://ewm.jinsheng.com/act/summit/red.html?barcode=' + barcode + '&timeStamp=' + timeStamp + '&authStr=' + authstr);
}

// iphonex 倒计时
// countDown();
// function countDown() {
//     $.post('/act/rule/' + activityId + '?name=sysTime', function (res) {
//         // 倒计时
//         $('.time-container').downCount({
//             date: '01/31/2018 08:00:00',
//             offset: 8, // 中国在东八区
//             now: new Date(res.systemTime)
//         });
//     });
// }

// 助力
$('[data-click="assisting-join"]').click(function () {
    $('.pop-assisting').removeClass('invisible');
    $('.assisting-step1').removeClass('invisible');
});

$('[data-click="assisting-close"]').click(function () {
    $('.pop-assisting').addClass('invisible');
    $('.assisting-step1').addClass('invisible');
    $('.tip-content p').addClass('invisible');
    $('.assisting-tip').removeClass('invisible');
    $('.assisting-share_btn').removeClass('invisible');
    $('.tip-content').removeClass('invisible');
});

$('[data-click="assisting-share_btn"]').click(function () {
    $('.pop-assisting').removeClass('invisible');
    $('.assisting-step1').addClass('invisible');
    $('.assisting-step2').removeClass('invisible');
});








