/**
 * @author fu
 * @file 拆红包
 * @CreateTime 08/21/2017
 */

 $('#input').val('');

var mobile = ''; // 用户手机号
var code = getQueryString('barcode');
var openId = '' // 用户的openid
var mark; // loading

button();

function buildparam() {
    var paramObj = {};
    paramObj.st = getQueryString('st');
    paramObj.vt = getQueryString('vt');
    paramObj.fvt = getQueryString('fvt');
    paramObj.res = getQueryString('res');
    paramObj.pdi = getQueryString('pdi');
    paramObj.pdn = getQueryString('pdn');
    paramObj.pdt = getQueryString('pdt');
    paramObj.pin = getQueryString('pin');
    paramObj.bn = getQueryString('bn');
    paramObj.ts = getQueryString('ts');
    paramObj.n = getQueryString('n');
    paramObj.sign = getQueryString('sign');
    paramObj.barcode = getQueryString('barcode');
    return JSON.stringify(paramObj);
}

/** 定位信息 */
var province = '';
var district = '';
var city = '';
var provinceCode = '';
var cityCode = '';
var districtCode = '';
var lat = 0;
var lng = 0;
var map = '';
var acc = 0;
// 地理位置
getP();

(function () {
    var TIME = 0;
    mark = setInterval(function () {
        if ($('.mark').hasClass('invisible')) {
            clearInterval(mark);
            return;
        }
        var $mark = $('.mark em');
        var tips = '加载中';
        var _TIME = TIME;
        while (--_TIME >= 0) {
            tips += '.';
        }
        if (++TIME > 3) {
            TIME = 0;
        }
        $mark.html(tips);
    }, 1000);
})();

// index接口
function run() {
    var url = '/act/rule/';
    url += activityId;
    url += '?name=index';

    function successFn(res) {
        var data = res.context || {};
        if (res.code === 1) {
            COOKIE = '; ' + document.cookie;
            openId = getCookie('openid') || '';
            // $('.main').removeClass('invisible');
            code = data.code || getQueryString('barcode');
            $('#mask').addClass('invisible');
            if (data.verifyTimes >= 1) {  // 多次验真
                $('.unqualify .count').text(data.count);
                $('.explain ').addClass('invisible');
                $('#startRed').addClass('margin-top');
                $('.qualify').addClass('invisible');
                $('#startRed').addClass('noRedpack'); // 将拆红包按钮置灰
                $('.unqualify').removeClass('invisible');
            }
            else {
                $('.explain ').removeClass('invisible');
                $('.qualify').removeClass('invisible');
            }
            $('#startRed').removeClass('invisible');
        }
        else {
            if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                alert(res.msg);
            }
            else {
                alert('服务器繁忙，请稍后重试~');
            }

        }

    }

    $.ajax({
        url: url,
        method: 'post',
        data: {
            param: buildparam(),
            x_lat: lat,
            x_lng: lng,
            x_acc: acc,
            province: province,
            city: city,
            district: district,
            x_province: province,
            x_provice_code: provinceCode,
            x_city: city,
            x_city_code: cityCode,
            x_district: district,
            x_district_code: districtCode,
            cache: false

        },
        success: successFn
    });
}

// cookie中取值 cookie中有barcode和scan_count
function getCookie(name) {
    var parts = COOKIE.split('; ' + name + '=');
    if (parts && parts.length === 2) {
        return parts[1].slice(0, parts[1].indexOf(';'));
    }
}

// 定位
function getPosition() {
    wx.error(function (res) {
        // console.log(res.errMsg);
        alert('微信错误消息' + res.errMsg);
        // options.callback();
    });
    var lnglatXY = [];
    wx.ready(function () {
        wx.hideAllNonBaseMenuItem();
        wx.getLocation({
            type: 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
            success: function (res) {
                lat = res.latitude; // 纬度，浮点数，范围为90 ~ -90
                lng = res.longitude; // 经度，浮点数，范围为180 ~ -180。
                lnglatXY = [lng, lat];
                // alert('经度' + lng + '纬度' + lat);
                regeocoder();
            },
            cancel: function (res) {
                if (localStorage.getItem('once')) {
                    $('.mask').addClass('none');
                }
                else {
                    $('.mask').removeClass('none');
                    $('.ban-box').removeClass('none');
                    localStorage.setItem('once', 'first');
                }
                run();
            },
            fail: function (res) {
                if (localStorage.getItem('once')) {
                    $('.mask').addClass('none');
                }
                else {
                    $('.mask').removeClass('none');
                    $('.ban-box').removeClass('none');
                    localStorage.setItem('once', 'first');
                }
                run();
            }
        });
    });

    function regeocoder() { // 逆地理编码
        var geocoder = new AMap.Geocoder({
            radius: 1000,
            extensions: 'all'
        });
        geocoder.getAddress(lnglatXY, function (status, result) {
            if (status === 'complete' && result.info === 'OK') {
                geocoder_CallBack(result); // 逆向地理编码，坐标-地址
            }
        });
    }

    function geocoder_CallBack(data) { // 逆向地理编码后获取地址信息
        if (data) {
            province = data.regeocode.addressComponent.province;

            city = data.regeocode.addressComponent.city || province;

            district = data.regeocode.addressComponent.district;

            // 区域编码
            districtCode = data.regeocode.addressComponent.adcode;

            // 省编码
            provinceCode = districtCode.substr(0, 2) + '000';

            // alert('省:' + province + provinceCode + '\n市:' +  city + '\n区:' + district + districtCode);

            if (localStorage.getItem('once')) {
                $('.mask').addClass('none');
            }
            else {
                $('.mask').removeClass('none');
                $('.ban-box').removeClass('none');
                localStorage.setItem('once', 'first');
            }
            run();
        }
    }

    // 解析定位错误信息
    function onError(data) {
        // alert(JSON.stringify(data));
        // console.log('定位失败');
        alert('定位失败！');
        run();
    }
}

function getP() {
    // if (window.localStorage.getItem('_AMap_AMap.Geolocation') === null) {
    //     alert('温馨提示：验真需要定位，下一步请允许“使用您的当前位置”。');
    // }
    map = new AMap.Map('container', {
        resizeEnable: true
    });
    getPosition();
    $('main').removeClass('invisible');
}

// 同意用户协议按钮

$('#myCheck').on('change', function () {
    // console.log($(this).is(':checked'));
    if ($('#myCheck').attr('checked')) {
        $('#myCheck').attr('checked', false);
        // $('#startRed').addClass('noRedpack'); // 将拆红包按钮置灰
    }
    else {
        $('#myCheck').attr('checked', true);
        // $('#startRed').removeClass('noRedpack'); // 拆红包按钮取消置灰
    }
    button();
});

function button() {
    if ($('#myCheck').attr('checked')) {
        $('#mycheck1').addClass('checked');
        $('#startRed').removeClass('noRedpack'); // 拆红包按钮取消置灰
    }
    else {
        $('#mycheck1').removeClass('checked');
        $('#startRed').addClass('noRedpack'); // 将拆红包按钮置灰
    }
}

// 点击按钮调用验真接口

$('#startRed').click(function () {
    // 盒内验证码
    var hCaptcha = $('#input').val();
    if ($(this).hasClass('noRedpack')) {
        return;
    }
    else if (hCaptcha == '' || hCaptcha.length != 4) {
        alert('请输入烟包翻盖内4位验证码');
        return;
    }
    else {
        $.ajax({
            url: '/act/rule/' + activityId + '?name=help',
            method: 'post',
            data: {
                code: code,
                pin: hCaptcha
            },
            success: function (res) {
                if (res.code === 1) {
                    $('.explain ').removeClass('invisible')
                        .removeClass('margin-top');
                    var context = res.context;

                    if (context.isFirst) {
                        if (context.leftTimes > 0) { // 用户第一次扫码
                            redPack(context.status);
                        }
                        else { // 用户已多次扫码
                            var text = res.context.msg_info;
                            var num = text.replace(/[^0-9]/ig, '');
                            $('.qualify').addClass('invisible')
                                .siblings('.unqualify').removeClass('invisible');
                            $('.count').text(num);
                            $('.explain ').addClass('invisible');
                            $('#startRed').addClass('margin-top');
                        }
                    }
                    else { // 用户已多次扫码
                        if (context.msg_code === 100086) { 
                            var text = res.context.msg_info;
                            var num= text.replace(/[^0-9]/ig, '');
                            $('.qualify').addClass('invisible')
                                .siblings('.unqualify').removeClass('invisible');
                            $('.count').text(num);
                            // $('#startRed').addClass('noRedpack');
                            $('.explain ').addClass('invisible');
                            $('#startRed').addClass('margin-top');
                        }
                    }
                    $('#myCheck').attr('checked', false);
                    $('#mycheck1').removeClass('checked');
                    $('#startRed').addClass('noRedpack'); // 将拆红包按钮置灰
                }
                else {
                    if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                        alert(res.msg);
                    }
                    else {
                        alert('服务器繁忙，请稍后重试~');
                    }
                }
            }
        });
    }

});

// 拆红包接口
function redPack(status) {
    $.ajax({
        url: '/act/rule/' + activityId + '?name=redpack',
        method: 'post',
        data: {
            code: code
        },
        success: function (res) {
            if (res.code === 1) {
                var orderid = '';
                var pid = '';
                var isVip = res.context.isVip;
                var isSuccess = res.context.isSuccess;
                var barcode = res.context.barcode;
                var authstr = res.context.authStr;
                var timeStamp = res.context.timeStamp;

                var cardFriendId = res.context.cardFriendId || '';
                var userId = res.context.userId || '';
                // 三选一需要参数
                window.sessionStorage.setItem('cardFriendId', cardFriendId);
                window.sessionStorage.setItem('userId', userId);
                window.sessionStorage.setItem('isNeedChoose', res.context.isNeedChoose);
                window.sessionStorage.setItem('cardType', res.context.cardType);
                // 跳转到积分商城需要参数
                window.sessionStorage.setItem('barcode', barcode);
                window.sessionStorage.setItem('authstr', authstr);
                window.sessionStorage.setItem('timeStamp', timeStamp);

                window.sessionStorage.setItem('score', ''); // 积分
                window.sessionStorage.setItem('orderid', '');
                // 助力
                window.sessionStorage.setItem('need_zhuli', res.context.need_zhuli); // 是否需要助力
                // alert(res.context.need_zhuli);
                if (res.context.pid === 'jxjinsxrp-card') { // 楼卡
                    pid = res.context.pid;
                    var lkImg = res.context.cardAddress;
                    window.sessionStorage.setItem('lkImg', lkImg);
                    window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?pid=' + pid + '&isSuccess=' + isSuccess + '&isVip=' + isVip + '&code=' + code + '&cache=false';
                }
                // else if (res.context.pid === 'jxjinsxrp-card-cy') { // 楼卡
                //     pid = res.context.pid;
                //     lkImg = res.context.cardAddress;
                //     window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?lkImg=' + lkImg + '&pid=' + pid + '&isSuccess=' + isSuccess + '&isVip=' + isVip;
                // }
                else {
                    var order = res.context.order;
                    var orderid = order.orderid;
                    if (res.context.need_zhuli) {
                        window.sessionStorage.setItem('user_openid', order.openid);
                        window.sessionStorage.setItem('orderid', orderid);
                        window.sessionStorage.setItem('price', res.context.details[0].price);
                    }

                    if (status === 2) { // 已绑定
                        isBind = true;
                        window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?orderid=' + orderid + '&isSuccess=' + isSuccess + '&isVip=' + isVip + '&cache=false';
                    }
                    else { // 未绑定
                        isBind = false;
                        $('#bind').removeClass('invisible');
                        // 绑定用户成功后调用拆红包接口
                        $('[data-click="close-redpack"]').click(function () {
                            window.location.href = window.location.origin + '/a/p/guangxi-jins-cons-prize-detail.html?orderid=' + orderid + '&isSuccess=' + isSuccess + '&isVip=' + isVip + '&cache=false';
                        });
                    }
                }

            }
            else {
                if (res.msg.indexOf('SyntaxError') === -1 || res.msg.indexOf('TypeError') === -1) {
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}


// 四位验证码
$('.input').on('input', function () {
    var val = $(this).val();
    if (val.length === 4) {
        $(this).blur();
    }
});



// 
// $('[data-click="close-phone"]').click(function () {
//     $(this).parent('')
// });




