/**
 * @author fu
 * @file 订单详情  三选一
 * @CreateTime 05/03/2018
**/
var img = '';
var price = '';
var userOpenid = '';
var orderid = '';
COOKIE = '; ' + document.cookie;
var score = '';
var userObj = {
    openId: getCookie('openid') || '', // 当前人的openid
    user_openid: getQueryString('user_openid') || '', // 发起人openid
    orderid: getQueryString('orderid') || '' // 订单id
};

// 点击链接增加对应的助力详情
addHelpUser();
function addHelpUser() {
    $.ajax({
        url: '/act/rule/JS0001DS001?name=add_help_user',
        method: 'post',
        data: {
            user_openid: userObj.user_openid,
            business_id: userObj.orderid, // 订单号
            friend_openid: userObj.openId,
            activity_id: activityId
        },
        success: function (res) {
            if (res.code === 1) {
                var context = res.context;
                var needHelpNum = context.needHelpNum; // 需要助力人数
                var friendList = context.friendList; // 已助力人数
                var html = '';
                var createTime_zhuli = context.createTime_zhuli;
                var startTime = new Date(createTime_zhuli.replace(/-/g, "/"));
                // 倒计时
                var month = startTime.getMonth() + 1;
                var endMonth = startTime.getMonth() + 1;
                var endDate = startTime.getDate() + 7;
                var endFullYear = startTime.getFullYear();
                if (month === 1 || month === 3 || month === 5 || month === 7 || month === 8 || month === 10) {
                    if ((startTime.getDate() + 7) > 31) {
                        endMonth = month + 1;
                        endDate = (startTime.getDate() + 7) - 31;
                    }
                }
                else if (month === 12) {
                    if ((startTime.getDate() + 7) > 31) {
                        endFullYear = startTime.getFullYear() + 1;
                        endMonth = 1;
                        endDate = endDate = (startTime.getDate() + 7) - 31;
                    }
                }
                else if (month === 2) {
                    if ((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)) { // 闰年 29天
                        if ((startTime.getDate() + 7) > 29) {
                            endMonth = month + 1;
                            endDate = (startTime.getDate() + 7) - 29;
                        }
                    }
                    else { // 平年 28天
                        if ((startTime.getDate() + 7) > 28) {
                            endMonth = month + 1;
                            endDate = (startTime.getDate() + 7) - 28;
                        }
                    }
                }
                var endTime = new Date(endFullYear + '/' + endMonth + '/' + endDate + ' ' + startTime.getHours() + ':' + startTime.getMinutes() + ':' + startTime.getSeconds()).getTime();
                if (startTime.getTime() >= endTime) {
                    
                }
                var endCoundownTime = endMonth + '/' +  endDate  + '/' + endFullYear + ' ' + startTime.getHours() + ':' + startTime.getMinutes() + ':' + startTime.getSeconds();

                $('.head-portrait').attr('src', context.userAvatar);
                $('.already-assisting').html(friendList.length);
                $('.yet-assisting').html(needHelpNum - friendList.length);

                $('.time-container').downCount({
                    date: endCoundownTime,
                    offset: 8, // 中国在东八区
                    now: new Date(res.systemTime)
                });
                // 倒计时end

                // 遍历放助力人图片张数
                for (var j = 0; j < friendList.length; j++) {
                    var friendInfo = JSON.parse(friendList[j]);
                    html += '<img class="firends-item_img" src="' + friendInfo.avatar + '">';
                }
                if ((needHelpNum - friendList.length) > 0) {
                    for (var i = 0; i < (needHelpNum - friendList.length); i++) {
                        html += '<img class="firends-item_img" src="https://weiop.oss-cn-beijing.aliyuncs.com/jiangxi8-28/img/assisting-img/assisting-friends_default.png">';
                    }
                }

                switch (needHelpNum) {
                    case 2:
                        $('.assisting-friends').addClass('plr-25');
                        break;
                    case 3:
                        $('.assisting-friends').addClass('plr-2');
                        break;
                    case 5:
                        $('.assisting-friends').addClass('plr-1');
                        break;
                }

                $('.assisting-friends').html(html);
                $('.price').html(context.orderFee + '元');
                $('.success-price').html(context.orderFee + '元');
                switch(context.orderFee) {
                    case 8.8:
                        $('.assisting-score').html('20积分');
                        $('.success-score').html('20');
                        score = 20;
                        break;
                    case 18:
                        $('.assisting-score').html('50积分');
                        $('.success-score').html('50');
                        score = 50;
                        break;
                    case 28:
                        $('.assisting-score').html('100积分');
                        $('.success-score').html('100');
                        score = 100;
                        break;
                    case 88:
                        $('.assisting-score').html('200积分');
                        $('.success-score').html('200');
                        score = 200;
                        break;
                }
                if (context.is_oneself) { // 自己看页面
                    $('.self-see').removeClass('invisible');
                    $('.total-people').html(needHelpNum + '人');
                }
                else { // 别人看页面
                    $('#winner-name').html('@' + context.userNickname);
                    $('.others-see').removeClass('invisible');
                }

                var status_zhuli = context.status_zhuli;
                if (status_zhuli === 0) { // 0 助力中
                    if (context.is_oneself) { // 自己看
                        $('#self-underway').removeClass('invisible');
                    }
                    else { // 别人看
                        $('#others-underway').removeClass('invisible');
                        $('#others-underway span').html(needHelpNum - friendList.length);
                    }
                }
                else if (status_zhuli === 1) { // 1 已成功
                    if (context.is_oneself) { // 自己看
                        $('#self-success').removeClass('invisible');
                        $('.receive-assisting_btn').removeClass('invisible');
                    }
                    else { // 别人看
                        if (context.is_help === 0) { // 未帮助力
                            $('.others').addClass('invisible');
                        }
                        $('#others-success').removeClass('invisible');
                    }
                }
                else if (status_zhuli === 2) { // 2代表助力失败
                    if (context.is_oneself === 1) { // 自己看页面
                        $('.receive-assisting_btn').removeClass('invisible');
                        $('.receive-assisting_btn').text('助力失败').addClass('gray-bg-color');
                    }
                    else { // 别人看页面
                        if (context.is_help === 0) { // 未帮助力
                            $('.others').text('本次助力无效！').removeClass('invisible');
                        }
                        else{
                            $('.others').html('您已为好友助力<b>1</b>次').removeClass('invisible');
                            $('#others-fail').removeClass('invisible');
                        }
                    }
                }
                else if (status_zhuli === 3) { // 自己看已领取
                    if (context.is_oneself) { // 自己看
                        $('#self-success').removeClass('invisible');
                        $('.receive-assisting_btn').removeClass('invisible');
                        $('.receive-assisting_btn').text('已领取').addClass('gray-bg-color');
                        // $('.receive-assisting_btn').off('click');
                    }
                    else { // 别人看
                        if (context.is_help === 0) { // 未帮助力
                            $('.others').addClass('invisible');
                        }
                        $('#others-success').removeClass('invisible');
                    }
                    
                }
            }
            else {
                if (res.msg.indexOf('SyntaxError') === -1) {
                    alert(res.msg);
                }
                else {
                    alert('服务器繁忙，请稍后重试~');
                }
            }
        }
    });
}

console.log($(this).hasClass('gray-bg-color'));
$('.receive-assisting_btn').click(function () {
    if ($(this).hasClass('gray-bg-color')) {
        $('.success-pop').removeClass('invisible');
        $('.mall').html('<b class="success-score">' + score  + '</b>积分已发放。您可以进入金圣家园公众号，点击<a class="score-mall" href="http://ewm.jinsheng.com/p/index.htm">积分商城</a> 查看。');
    }
    else {
        $(this).addClass('gray-bg-color');
        $.ajax({
            url: '/act/rule/JS0001DS001?name=send_redpack_point',
            method: 'post',
            data: {
                order_id: userObj.orderid,
                activity_id: activityId,
                user_openid: userObj.user_openid,
            },
            success: function (res) {
                if (res.code === 1) {
                    totalScore = res.context.totalScore;
                    window.sessionStorage.setItem('totalScore', totalScore);
                    $('#total-score').html(res.context.totalScore);
                    $('.success-pop').removeClass('invisible');
                    if (res.context.isReg) { // 已注册
                        $('.score-mall').attr('href', 'http://ewm.jinsheng.com/p/uc-points.htm');
                    }
                    else { // 未注册
                        $('.score-mall').attr('href', 'http://ewm.jinsheng.com/p/reg.htm');
                    }
                }
                else {
                    if (res.msg.indexOf('SyntaxError') === -1) {
                        alert(res.msg);
                    }
                    else {
                        alert('服务器繁忙，请稍后重试~');
                    }
                }
                // window.location.href = '/a/p/guangxi-jins-cons-my-prize.html?index=2';
            }
        });
    }
});

$('[data-click="confirm-btn"]').click(function () {
    location.replace(location.href);
    $('.success-pop').addClass('invisible');
});




